# Screen Tracker Demo — 15-minute Touch Session

This Android demo captures the screen only after the user grants Android's
MediaProjection permission. Frames are processed locally and are not uploaded.

## 15-minute touch session
- 15:00 countdown with start, pause, resume, and reset controls
- Live touch coordinates normalized to 0–1000
- Down, move, up/release, cancel, and held-duration reporting
- Touch-event counter while the session is running
- Completion summary when the 15 minutes expire
- Scrollable interface so the controls remain reachable on smaller phones

Touch events are observed on the demo's own touch pad only. The app does not
read arbitrary touch input from other apps or inject input into other apps.

## Build
Open this folder in Android Studio, or run:

```bash
gradle testDebugUnitTest --no-daemon
gradle assembleDebug --no-daemon
```

The debug APK is generated at:
`app/build/outputs/apk/debug/app-debug.apk`

A GitHub Actions workflow is included at
`.github/workflows/android-build.yml`. Push this project to a GitHub repository
and run the workflow to build and download the APK artifact.
